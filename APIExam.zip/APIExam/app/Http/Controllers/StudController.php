<?php

namespace App\Http\Controllers;

use App\Models\Student;
use App\Models\Subjects;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\View;
//use Illuminate\Support\Facades\DB;

class StudController extends Controller
{

   public function index()
   {
        $students = Student::join('subjects', 'students.id', '=', 'subjects.id')
                            ->get(['students.*', 
                                   'subjects.math', 
                                   'subjects.english', 
                                   'subjects.filipino', 
                                   'subjects.history', 
                                   'subjects.science']);

                        return view('students.index',compact('students'));

       /*$students = (Student::latest()->paginate(7));
        return view('students.index',compact('students'))
            ->with('i',(request()->input('page',1) - 1) * 5);*/
            

   }

   public function create()
   {
       return view('students.create');

   }

    public function store(Request $request)
   {
       /*$request->validate($request, [
           'studname' => 'required',
           'studgender' => 'required',
           'studbirthdate' => 'required',
           'studaddress' => 'required',
           'studlevel' => 'required',
           'math' => 'required',
           'english' => 'required',
           'filipino' => 'required',
           'history' => 'required',
           'science' => 'required',  
       ]);*/
       $students = new Student();
       $students->studname = $request->input("studname");
       $students->studgender = $request->input("studgender");
       $students->studbirthdate = $request->input("studbirthdate");
       $students->studaddress = $request->input("studaddress");
       $students->studlevel = $request->input("studlevel");
       $students->save();
     
       $subjects = new Subjects();
       $subjects->id = $students->id;
       $subjects->math = $request->input("math");
       $subjects->english = $request->input("english");
       $subjects->filipino = $request->input("filipino");
       $subjects->history = $request->input("history");
       $subjects->science = $request->input("science");
       $subjects->save();

        //Student::create($request->all());
        return redirect()->route('students.index')
        ->with('success', 'Student created successfully!');
   }


    public function show($students)
    {
        Student::join('subjects', 'students.id', '=', 'subjects.id')
                            ->get(['students.*', 
                                   'subjects.math', 
                                   'subjects.english', 
                                   'subjects.filipino', 
                                   'subjects.history', 
                                   'subjects.science']);
        return view('students.show', [
            'students' => Student::findOrFail($students)
        ]);
    }

    public function edit(Student $student)
   {
       return view('students.edit', compact('student'));
   }
  

    public function update(Request $request, Student $student)
   {
        $request->validate([
                
        ]);
      
       $student->update($request->all());

       return redirect()->route('students.index')
       ->with('success', 'Student updated successfully!');
   }


    public function destroy(Student $student)
   {
       $student->delete();

       return redirect()->route('students.index')
       ->with('success', 'Student deleted successfully!');
   }

}
