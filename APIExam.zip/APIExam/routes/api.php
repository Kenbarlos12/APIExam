<?php

use Illuminate\Http\Request;
use App\Http\Controllers\StudController;
use Illuminate\Support\Facades\Route;


/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
|
| Here is where you can register API routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| is assigned the "api" middleware group. Enjoy building your API!
|
*/


/*Route::middleware('auth:api')->get('/users', function (Request $request) {
    return $request->users();
});*/

    Route::resource('/students', 'App\Http\Controllers\StudController');

    
    //Route::put('/students', 'StudController@update')->name('students.add');

    //Route::get('/test', 'App\Http\Controllers\StudController@index');
    


    //Route::post('/students', 'App\Http\Controllers\StudController@index');
    //Route::post('/students/{id}', 'App\Http\Controllers\StudController@store');
    //Route::get('/students', 'App\Http\Controllers\StudController@create');
    //Route::put('/students/{id}', 'App\Http\Controllers\StudController@update');
    //Route::delete('/students/{id}','App\Http\Controllers\StudController@destroy');
