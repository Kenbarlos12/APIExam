

<?php $__env->startSection('content'); ?>

<div class="row">
    <div class="col-md-12 margin-tb">
        <div class="pull-left">
            <h2>Add New Student</h2>
        </div>
        <div class="pull-right">
            <a class="btn btn-primary" href="<?php echo e(route('students.index')); ?>">Back</a>
        </div>
    </div>    
</div>



<form action="<?php echo e(route('students.store')); ?>" method="POST">

<?php echo csrf_field(); ?>

    <div class="col-xs-12 col-sm-12 col-md-12">
        <div class="form-group">
            <strong>Student Name</strong>
            <input type="text" name="studname" class="form-control" placeholder="Student Name">
        </div>
    </div>

    <div class="col-xs-12 col-sm-12 col-md-12">
        <div class="form-group">
            <strong>Gender</strong>
            <input type="text" name="studgender" class="form-control" placeholder="Gender">
        </div>
    </div>

    <div class="col-xs-12 col-sm-12 col-md-12">
        <div class="form-group">
            <strong>Birthdate</strong>
            <input type="text" name="studbirthdate" class="form-control" placeholder="Student Birthdate">
        </div>
    </div>

    <div class="col-xs-12 col-sm-12 col-md-12">
        <div class="form-group">
            <strong>Address</strong>
            <input type="text" name="studaddress" class="form-control" placeholder="Student Address">
        </div>
    </div>

    <div class="col-xs-12 col-sm-12 col-md-12">
        <div class="form-group">
            <strong>Level</strong>
            <input type="text" name="studlevel" class="form-control" placeholder="Student Level">
        </div>
    </div>

    <div class="col-xs-12 col-sm-12 col-md-12">
        <div class="form-group">
            <strong>Math Grade</strong>
            <input type="text" name="math" class="form-control" placeholder="Math">
        </div>
    </div>

    <div class="col-xs-12 col-sm-12 col-md-12">
        <div class="form-group">
            <strong>English Grade</strong>
            <input type="text" name="english" class="form-control" placeholder="English">
        </div>
    </div>

    <div class="col-xs-12 col-sm-12 col-md-12">
        <div class="form-group">
            <strong>Filipino Grade</strong>
            <input type="text" name="filipino" class="form-control" placeholder="Filipino">
        </div>
    </div>

    <div class="col-xs-12 col-sm-12 col-md-12">
        <div class="form-group">
            <strong>History Grade</strong>
            <input type="text" name="history" class="form-control" placeholder="History">
        </div>
    </div>

    <div class="col-xs-12 col-sm-12 col-md-12">
        <div class="form-group">
            <strong>Science Grade</strong>
            <input type="text" name="science" class="form-control" placeholder="Science">
        </div>
    </div>

    <div class="col-xs-12 col-sm-12 col-md-12 text-center">
        <button type="submit" class="btn btn-primary">Submit</button>
    </div>
</div>

</form>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('students.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\APIExam\resources\views/students/create.blade.php ENDPATH**/ ?>