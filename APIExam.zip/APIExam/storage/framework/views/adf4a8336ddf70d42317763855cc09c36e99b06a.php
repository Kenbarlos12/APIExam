

<?php $__env->startSection('content'); ?>


<div class="row">
    <div class="col-lg-12 margin-tb">
        <div class="pull-left">
            <h2>Update info</h2>
        </div>
        <div class="pull-right">
            <a class="btn btn-primary" href="<?php echo e(route('students.index')); ?>">Back</a>
            
        </div>
    </div>    
</div>

<?php if($errors->any()): ?>
<div class="alert alert-danger">
    <strong>Whoops!</strong>There's some problem with your input.<br><br>
    <ul>
        <?php $__currentLoopData = $error->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <li><?php echo e($error); ?></li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>
</div>>
<?php endif; ?>

<form action="<?php echo e(route('students.update', $student->id, $student->subj_id)); ?>" method="POST">

<?php echo csrf_field(); ?>

<?php echo method_field('PUT'); ?>

<div class="row">
    <div class="col-xs-12 col-sm-12 col-md-12">
        <div class="form-group">
            <strong>Student Name:</strong>
            <input type="text" name="studname" value="<?php echo e($student->studname); ?>" class="form-control" placeholder="Student Name">
        </div>
    </div>

    <div class="col-xs-12 col-sm-12 col-md-12">
        <div class="form-group">
            <strong>Gender:</strong>
            <input type="text" name="studgender" value="<?php echo e($student->studgender); ?>" class="form-control" placeholder="Gender">
        </div>
    </div>

    <div class="col-xs-12 col-sm-12 col-md-12">
        <div class="form-group">
            <strong>Birthdate:</strong>
            <input type="text" name="studbirthdate" value="<?php echo e($student->studbirthdate); ?>" class="form-control" placeholder="Student Birthdate">
        </div>
    </div>

    <div class="col-xs-12 col-sm-12 col-md-12">
        <div class="form-group">
            <strong>Address:</strong>
            <input type="text" name="studaddress" value="<?php echo e($student->studaddress); ?>" class="form-control" placeholder="Student Address">
        </div>
    </div>

    <div class="col-xs-12 col-sm-12 col-md-12">
        <div class="form-group">
            <strong>Level:</strong>
            <input type="text" name="studlevel" value="<?php echo e($student->studlevel); ?>" class="form-control" placeholder="Student Level">
        </div>
    </div>

    <div class="col-xs-12 col-sm-12 col-md-12">
        <div class="form-group">
            <strong>Math:</strong>
            <input type="text" name="math" value="<?php echo e($student->math); ?>" class="form-control" placeholder="Math Grade">
        </div>
    </div>

    <div class="col-xs-12 col-sm-12 col-md-12">
        <div class="form-group">
            <strong>English:</strong>
            <input type="text" name="english" value="<?php echo e($student->english); ?>" class="form-control" placeholder="English Grade">
        </div>
    </div>

    <div class="col-xs-12 col-sm-12 col-md-12">
        <div class="form-group">
            <strong>Filipino:</strong>
            <input type="text" name="filipino" value="<?php echo e($student->filipino); ?>" class="form-control" placeholder="Filipino Grade">
        </div>
    </div>

    <div class="col-xs-12 col-sm-12 col-md-12">
        <div class="form-group">
            <strong>History:</strong>
            <input type="text" name="history" value="<?php echo e($student->history); ?>" class="form-control" placeholder="History Grade">
        </div>
    </div>

    <div class="col-xs-12 col-sm-12 col-md-12">
        <div class="form-group">
            <strong>Science:</strong>
            <input type="text" name="science" value="<?php echo e($student->science); ?>" class="form-control" placeholder="Science Grade">
        </div>
    </div>

    <div class="col-xs-12 col-sm-12 col-md-12 text-center">
        <button type="submit" class="btn btn-primary">Submit</button>
    </div>
</div>

</form>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('students.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\APIExam\resources\views/students/add.blade.php ENDPATH**/ ?>