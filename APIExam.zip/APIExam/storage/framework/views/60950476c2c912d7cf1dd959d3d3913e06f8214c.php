<!DOCTYPE html>
<html>
    <head>

        <title>Laravel API Test</title>

        <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
        
    </head>
    
    <body>
        <div class="container">

            <?php echo $__env->yieldContent('content'); ?>

        </div>
    </body>

</html>
<?php /**PATH C:\xampp\htdocs\APIExam\resources\views/students/layout.blade.php ENDPATH**/ ?>