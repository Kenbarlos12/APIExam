<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class ApiStudents extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('students', function (Blueprint $table) {
            $table->id();
            $table->string('studname');
            $table->string('studgender');
            $table->date('studbirthdate');
            $table->string('studaddress');
            $table->string('studlevel');
            /*$table->string('math');
            $table->string('english');
            $table->string('filipino');
            $table->string('history');
            $table->string('science');*/

            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('students');
    }
}
