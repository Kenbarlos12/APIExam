@extends('students.layout')

@section('content')


<div class="row">
    <div class="col-lg-12 margin-tb">
        <div class="pull-left">
            <h2>Update info</h2>
        </div>
        <div class="pull-right">
            <a class="btn btn-primary" href="{{route('students.index')}}">Back</a>
            
        </div>
    </div>    
</div>

    @if ($errors->any())
        <div class="alert alert-danger">
            <strong>Whoops!</strong> There were some problems with your input.<br><br>
            <ul>
                @foreach ($errors->all() as $error)
                    <li>{{ $error }}</li>
                @endforeach
            </ul>
        </div>
    @endif


<form action="{{ route('students.update', $student->id) }}" method="POST">

@csrf

@method('PUT')

<div class="row">
    <div class="col-xs-12 col-sm-12 col-md-12">
        <div class="form-group">
            <strong>Student Name:</strong>
            <input type="text" name="studname" value="{{$student->studname}}" class="form-control" placeholder="Student Name">
        </div>
    </div>

    <div class="col-xs-12 col-sm-12 col-md-12">
        <div class="form-group">
            <strong>Gender:</strong>
            <input type="text" name="studgender" value="{{$student->studgender}}" class="form-control" placeholder="Gender">
        </div>
    </div>

    <div class="col-xs-12 col-sm-12 col-md-12">
        <div class="form-group">
            <strong>Birthdate:</strong>
            <input type="text" name="studbirthdate" value="{{$student->studbirthdate}}" class="form-control" placeholder="Student Birthdate">
        </div>
    </div>

    <div class="col-xs-12 col-sm-12 col-md-12">
        <div class="form-group">
            <strong>Address:</strong>
            <input type="text" name="studaddress" value="{{$student->studaddress}}" class="form-control" placeholder="Student Address">
        </div>
    </div>

    <div class="col-xs-12 col-sm-12 col-md-12">
        <div class="form-group">
            <strong>Level:</strong>
            <input type="text" name="studlevel" value="{{$student->studlevel}}" class="form-control" placeholder="Student Level">
        </div>
    </div>

    <div class="col-xs-12 col-sm-12 col-md-12">
        <div class="form-group">
            <strong>Math:</strong>
            <input type="text" name="math" value="{{$student->math}}" class="form-control" placeholder="Math Grade">
        </div>
    </div>

    <div class="col-xs-12 col-sm-12 col-md-12">
        <div class="form-group">
            <strong>English:</strong>
            <input type="text" name="english" value="{{$student->english}}" class="form-control" placeholder="English Grade">
        </div>
    </div>

    <div class="col-xs-12 col-sm-12 col-md-12">
        <div class="form-group">
            <strong>Filipino:</strong>
            <input type="text" name="filipino" value="{{$student->filipino}}" class="form-control" placeholder="Filipino Grade">
        </div>
    </div>

    <div class="col-xs-12 col-sm-12 col-md-12">
        <div class="form-group">
            <strong>History:</strong>
            <input type="text" name="history" value="{{$student->history}}" class="form-control" placeholder="History Grade">
        </div>
    </div>

    <div class="col-xs-12 col-sm-12 col-md-12">
        <div class="form-group">
            <strong>Science:</strong>
            <input type="text" name="science" value="{{$student->science}}" class="form-control" placeholder="Science Grade">
        </div>
    </div>

    <div class="col-xs-12 col-sm-12 col-md-12 text-center">
        <button type="submit" class="btn btn-primary">Submit</button>
    </div>
</div>

</form>

@endsection