@extends('students.layout')

@section('content')

<div class="pull-left">

    <h2>Laravel CRUD</h2>

</div>

<div class="row">
    <div class="col-lg-12 margin-tb">
        <div class="pull-right">
        <a class="btn btn-success" href="{{route('students.create')}}">Create New Student</a>

        
        
        </div>

    </div>
</div> 

@if($message = Session::get('success'))
    <div class="alert alert-success">
        <p>{{$message}}</p>
    </div>
@endif

<table class="table table-bordered">
    <tr>
        <th>Student Name</th>
        <th>Gender</th>
        <th>Birthdate</th>
        <th>Address</th>
        <th>Level</th>
        <th>Math</th>
        <th>English</th>
        <th>Filipino</th>
        <th>History</th>
        <th>Science</th>
        <th width="280px">Action</th>
    </tr>

    @foreach ($students as $students)

    <tr>
        <td>{{$students->studname}}</td>
        <td>{{$students->studgender}}</td>
        <td>{{$students->studbirthdate}}</td>
        <td>{{$students->studaddress}}</td>
        <td>{{$students->studlevel}}</td>
        <td>{{$students->math}}</td>
        <td>{{$students->english}}</td>
        <td>{{$students->filipino}}</td>
        <td>{{$students->history}}</td>
        <td>{{$students->science}}</td>

        <td> 
            <form action="{{route('students.destroy', $students->id)}}" method="POST" >

        <a class="btn btn-info" href="{{route('students.show', $students->id)}}">Show</a>
        <a class="btn btn-primary" href="{{route('students.edit', $students->id)}}">Edit</a>

        @csrf
        
        @method('DELETE')

        <button type="submit" class="btn btn-danger">Delete</button>

        </form>
        </td>
    </tr>
    
    @endforeach
</table>
